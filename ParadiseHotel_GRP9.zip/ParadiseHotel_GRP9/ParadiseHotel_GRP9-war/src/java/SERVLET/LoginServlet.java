/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SERVLET;

import SESSIONBEANS.LoginSessionBeanRemote;
import ENTITY.Paradiselogin;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author urvish
 */
public class LoginServlet extends HttpServlet
{

    LoginSessionBeanRemote loginSessionBeanRemote;
    HttpSession Session;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter())
        {
            if (request.getSession(true).getAttribute("c") != null)
            {
                loginSessionBeanRemote = (LoginSessionBeanRemote) request.getSession(true).getAttribute("c");
                System.out.print("from existing session");
            }
            else
            {
                InitialContext ic;
                try
                {
                    ic = new InitialContext();
                    Object o = ic.lookup(LoginSessionBeanRemote.class.getName());
                    loginSessionBeanRemote = (LoginSessionBeanRemote) o;
                    Session = request.getSession(true);
                    Session.setAttribute("c", loginSessionBeanRemote);
                    System.out.print("newly create from session");
                }
                catch (NamingException ex)
                {
                    Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            String email = request.getParameter("email");
            String password = request.getParameter("password");
            if (email != null)
            {
                RequestDispatcher rd;
                Boolean b = loginSessionBeanRemote.getAuthenticatedUser(email, password);
                Paradiselogin obj = (Paradiselogin) loginSessionBeanRemote.getUser();
                String ut = null;
                if (obj != null)
                {
                    ut = obj.getUsertype();
                }

                if ("U".equalsIgnoreCase(ut))
                {
                    rd = request.getRequestDispatcher("index.jsp");
                    rd.forward(request, response);
                }
                else if ("A".equalsIgnoreCase(ut))
                {
                    rd = request.getRequestDispatcher("admin/index.jsp");
                    rd.forward(request, response);
                }
                else
                {
                    Session.removeAttribute("c");
                    Session.invalidate();
                    request.setAttribute("errorMessage", "Login credentials are incorrect.");
                    rd = request.getRequestDispatcher("login.jsp");
                    rd.include(request, response);
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>
}
