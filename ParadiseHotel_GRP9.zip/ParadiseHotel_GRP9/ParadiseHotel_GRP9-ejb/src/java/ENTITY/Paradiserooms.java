/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ENTITY;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author urvish
 */
@Entity
@Table(name = "PARADISEROOMS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Paradiserooms.findAll", query = "SELECT p FROM Paradiserooms p"),
    @NamedQuery(name = "Paradiserooms.findByRoomnumber", query = "SELECT p FROM Paradiserooms p WHERE p.roomnumber = :roomnumber"),
    @NamedQuery(name = "Paradiserooms.findByRoomtype", query = "SELECT p FROM Paradiserooms p WHERE p.roomtype = :roomtype"),
    @NamedQuery(name = "Paradiserooms.findByPrice", query = "SELECT p FROM Paradiserooms p WHERE p.price = :price"),
    @NamedQuery(name = "Paradiserooms.findByServices", query = "SELECT p FROM Paradiserooms p WHERE p.services = :services"),
    @NamedQuery(name = "Paradiserooms.findByImage", query = "SELECT p FROM Paradiserooms p WHERE p.image = :image"),
    @NamedQuery(name = "Paradiserooms.findByIsavailable", query = "SELECT p FROM Paradiserooms p WHERE p.isavailable = :isavailable")})
public class Paradiserooms implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ROOMNUMBER")
    private Integer roomnumber;
    @Size(max = 30)
    @Column(name = "ROOMTYPE")
    private String roomtype;
    @Column(name = "PRICE")
    private Integer price;
    @Size(max = 150)
    @Column(name = "SERVICES")
    private String services;
    @Size(max = 40)
    @Column(name = "IMAGE")
    private String image;
    @Size(max = 3)
    @Column(name = "ISAVAILABLE")
    private String isavailable;

    public Paradiserooms() {
    }

    public Paradiserooms(Integer roomnumber) {
        this.roomnumber = roomnumber;
    }

    public Integer getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(Integer roomnumber) {
        this.roomnumber = roomnumber;
    }

    public String getRoomtype() {
        return roomtype;
    }

    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getIsavailable() {
        return isavailable;
    }

    public void setIsavailable(String isavailable) {
        this.isavailable = isavailable;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (roomnumber != null ? roomnumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paradiserooms)) {
            return false;
        }
        Paradiserooms other = (Paradiserooms) object;
        if ((this.roomnumber == null && other.roomnumber != null) || (this.roomnumber != null && !this.roomnumber.equals(other.roomnumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ENTITY.Paradiserooms[ roomnumber=" + roomnumber + " ]";
    }
    
}
