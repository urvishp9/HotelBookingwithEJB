/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ENTITY;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author urvish
 */
@Entity
@Table(name = "PARADISELOGIN")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Paradiselogin.findAll", query = "SELECT p FROM Paradiselogin p"),
     @NamedQuery(name = "Paradiselogin.findUser", query = "SELECT h FROM Paradiselogin h  WHERE h.email = :email AND h.password = :password"),
    @NamedQuery(name = "Paradiselogin.findByEmail", query = "SELECT p FROM Paradiselogin p WHERE p.email = :email"),
    @NamedQuery(name = "Paradiselogin.findByName", query = "SELECT p FROM Paradiselogin p WHERE p.name = :name"),
    @NamedQuery(name = "Paradiselogin.findByPassword", query = "SELECT p FROM Paradiselogin p WHERE p.password = :password"),
    @NamedQuery(name = "Paradiselogin.findByUsertype", query = "SELECT p FROM Paradiselogin p WHERE p.usertype = :usertype")})
public class Paradiselogin implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 20)
    @Column(name = "NAME")
    private String name;
    @Size(max = 10)
    @Column(name = "PASSWORD")
    private String password;
    @Size(max = 5)
    @Column(name = "USERTYPE")
    private String usertype;

    public Paradiselogin() {
    }

    public Paradiselogin(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (email != null ? email.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paradiselogin)) {
            return false;
        }
        Paradiselogin other = (Paradiselogin) object;
        if ((this.email == null && other.email != null) || (this.email != null && !this.email.equals(other.email))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ENTITY.Paradiselogin[ email=" + email + " ]";
    }
    
}
