/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ENTITY;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author urvish
 */
@Entity
@Table(name = "PARADISERESERVATION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Paradisereservation.findAll", query = "SELECT p FROM Paradisereservation p"),
    @NamedQuery(name = "Paradisereservation.findByReservationid", query = "SELECT p FROM Paradisereservation p WHERE p.reservationid = :reservationid"),
    @NamedQuery(name = "Paradisereservation.findByCheckin", query = "SELECT p FROM Paradisereservation p WHERE p.checkin = :checkin"),
    @NamedQuery(name = "Paradisereservation.findByCheckout", query = "SELECT p FROM Paradisereservation p WHERE p.checkout = :checkout"),
    @NamedQuery(name = "Paradisereservation.findBySpecialservice", query = "SELECT p FROM Paradisereservation p WHERE p.specialservice = :specialservice"),
    @NamedQuery(name = "Paradisereservation.findByRoomnumber", query = "SELECT p FROM Paradisereservation p WHERE p.roomnumber = :roomnumber"),
    @NamedQuery(name = "Paradisereservation.findByEmail", query = "SELECT p FROM Paradisereservation p WHERE p.email = :email"),
    @NamedQuery(name = "Paradisereservation.findByPrice", query = "SELECT p FROM Paradisereservation p WHERE p.price = :price")})
public class Paradisereservation implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "RESERVATIONID")
    private Integer reservationid;
    @Column(name = "CHECKIN")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkin;
    @Column(name = "CHECKOUT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkout;
    @Size(max = 100)
    @Column(name = "SPECIALSERVICE")
    private String specialservice;
    @Column(name = "ROOMNUMBER")
    private Integer roomnumber;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 30)
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PRICE")
    private Integer price;

    public Paradisereservation() {
    }

    public Paradisereservation(Integer reservationid) {
        this.reservationid = reservationid;
    }

    public Integer getReservationid() {
        return reservationid;
    }

    public void setReservationid(Integer reservationid) {
        this.reservationid = reservationid;
    }

    public Date getCheckin() {
        return checkin;
    }

    public void setCheckin(Date checkin) {
        this.checkin = checkin;
    }

    public Date getCheckout() {
        return checkout;
    }

    public void setCheckout(Date checkout) {
        this.checkout = checkout;
    }

    public String getSpecialservice() {
        return specialservice;
    }

    public void setSpecialservice(String specialservice) {
        this.specialservice = specialservice;
    }

    public Integer getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(Integer roomnumber) {
        this.roomnumber = roomnumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reservationid != null ? reservationid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paradisereservation)) {
            return false;
        }
        Paradisereservation other = (Paradisereservation) object;
        if ((this.reservationid == null && other.reservationid != null) || (this.reservationid != null && !this.reservationid.equals(other.reservationid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ENTITY.Paradisereservation[ reservationid=" + reservationid + " ]";
    }

    public void setEmail(Paradiselogin hl) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setRoomnumber(Paradiserooms hotelroom) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
