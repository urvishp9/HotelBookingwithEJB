/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package STATEFUL;

import SESSIONBEANS.LoginSessionBeanRemote;
import ENTITY.Paradiselogin;
import java.util.List;
import javax.ejb.Stateful;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.Query;
/**
 *
 * @author urvish
 */
@Stateful
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class LoginSessionBean implements LoginSessionBeanRemote {
     @javax.persistence.PersistenceContext(unitName = "ParadiseHotel_GRP9-ejbPU")
    private EntityManager em;
    Paradiselogin loginuser;

    @Override
    public Boolean getAuthenticatedUser(String email, String password)
    {

        Query query = em.createNamedQuery("Paradiselogin.findUser");
        query.setParameter("email", email);
        query.setParameter("password", password);
        List a = query.getResultList();
        for (Object temp : a)
        {
            loginuser = (Paradiselogin) temp;
        }
        if (query.getResultList().isEmpty())
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    @Override
    public Paradiselogin getUser()
    {
        return loginuser;
    }
    
}
