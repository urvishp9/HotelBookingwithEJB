/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package STATELESS;
import SESSIONBEANS.RegisterSessionBeanRemote;
import ENTITY.Paradiselogin;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;

/**
 *
 * @author urvish
 */
@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class RegisterSessionBean implements RegisterSessionBeanRemote{
      @javax.persistence.PersistenceContext(unitName = "ParadiseHotel_GRP9-ejbPU")
    private EntityManager em;

    @Override
    public Boolean insertUser(Object obj)
    {
        Paradiselogin hl = (Paradiselogin) obj;
        if (check(hl.getEmail()))
        {
            em.persist(hl);
            return true;
        }
        else
        {
            return false;
        }
    }

    public Boolean check(String email)
    {
        Paradiselogin hl = em.find(Paradiselogin.class, email);
        if (hl != null)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}
