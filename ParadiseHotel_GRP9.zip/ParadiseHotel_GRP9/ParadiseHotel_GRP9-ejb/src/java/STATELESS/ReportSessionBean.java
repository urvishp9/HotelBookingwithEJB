/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package STATELESS;
import SESSIONBEANS.ReportSessionBeanRemote;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author urvish
 */
@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class ReportSessionBean implements ReportSessionBeanRemote {
     @javax.persistence.PersistenceContext(unitName = "ParadiseHotel_GRP9-ejbPU")
    private EntityManager em;
    List myList = new ArrayList();

    @Override
    public List dateRange(Date startdDate, Date endDate)
    {
        Query query = em.createNamedQuery("Paradisereservation.findAll");
        myList = query.getResultList();
        return myList;
    }

    @Override
    public List priceRange(int a, int b)
    {
       Query query = em.createNamedQuery("Paradisereservation.findAll");
        myList = query.getResultList();
        return myList;
    }

    @Override
    public List floor(int a)
    {
        Query query = em.createNamedQuery("Paradisereservation.findAll");
        myList = query.getResultList();
        return myList;
    }
}
