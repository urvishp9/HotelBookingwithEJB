/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package STATELESS;
import SESSIONBEANS.RoomSessionBeanRemote;
import ENTITY.Paradisecontact;
import ENTITY.Paradisereservation;
import ENTITY.Paradiserooms;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author urvish
 */
@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class RoomSessionBean implements RoomSessionBeanRemote{
    
    @javax.persistence.PersistenceContext(unitName = "ParadiseHotel_GRP9-ejbPU")
    private EntityManager em;
    List a = null;

    public List getRoomDetails()
    {
        Query query = em.createNamedQuery("Paradiserooms.findAll");
        a = query.getResultList();
        return a;
    }

    public List getReservationDetails()
    {
        Query query = em.createNamedQuery("Paradisereservation.findAll");
        a = query.getResultList();
        return a;
    }

    @Override
    public void deleteReservation(int id)
    {
        em.remove(em.find(Paradisereservation.class, id));
    }

    @Override
    public void deleteRooms(int id)
    {
        em.remove(em.find(Paradiserooms.class, id));
    }
    
@Override
    public void bookRoom(Object o)
    {
        Paradisereservation hr = (Paradisereservation) o;
        Integer i = getRegisterationID();
        hr.setReservationid(i);
        em.persist(hr);
    }
    

    public Integer getRegisterationID()
    {

        Query query = em.createNamedQuery("Paradisereservation.getMaxID");
        List m = new ArrayList();
        m = query.getResultList();

        if (!m.isEmpty())
        {
            Paradisereservation hr = null;
            for (Object temp : m)
            {
                hr = (Paradisereservation) temp;
            }
            return hr.getReservationid() + 1;
        }
        return 1;
    }

    @Override
    public void AddRoom(Object o)
    {
        em.persist((Paradiserooms) o);
    }

    @Override
    public void UpdateRoom(Object o)
    {
        em.merge((Paradiserooms) o);
    }
    
    @Override
    public Integer getContactID()
    {

        Query query = em.createNamedQuery("Paradisecontact.getMaxID");
        List m = new ArrayList();
        m = query.getResultList();

        if (!m.isEmpty())
        {
            Paradisecontact hr = null;
            for (Object temp : m)
            {
                hr = (Paradisecontact) temp;
            }
            return hr.getContactid()+ 1;
        }
        return 1;
    }
}
