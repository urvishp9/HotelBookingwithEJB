/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SESSIONBEANS;

import java.util.Date;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author urvish
 */
@Remote
public interface ReportSessionBeanRemote {
   public List dateRange(Date startdDate, Date endDate);
    public List priceRange(int a,int b);
    public List floor(int a);  
}
