/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SESSIONBEANS;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author urvish
 */
@Remote
public interface RoomSessionBeanRemote {
     List getRoomDetails();

    public List getReservationDetails();

    public void bookRoom(Object o);

    public void AddRoom(Object o);

    public void UpdateRoom(Object o);

    public void deleteReservation(int id);

    public void deleteRooms(int id);

    public Integer getContactID();
}
