/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Forms;

import Business.UserManager;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Urvish
 */
public class Login implements ActionListener{
		JTextField userText = new JTextField(20);
		JPasswordField passwordText = new JPasswordField(20);
    public Login(){
        
         JFrame frame = new JFrame("Login Paradise Desktop App");
		frame.setSize(300, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.add(panel);

		frame.setVisible(true);
		panel.setLayout(null);

		JLabel userLabel = new JLabel("User");
		userLabel.setBounds(10, 10, 80, 25);
		panel.add(userLabel);

		userText.setBounds(100, 10, 160, 25);
		panel.add(userText);

		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setBounds(10, 40, 80, 25);
		panel.add(passwordLabel);

		passwordText.setBounds(100, 40, 160, 25);
		panel.add(passwordText);

		JButton loginButton = new JButton("login");
		loginButton.setBounds(10, 80, 80, 25);
		panel.add(loginButton);
		
		JButton registerButton = new JButton("register");
		registerButton.setBounds(180, 80, 80, 25);
		panel.add(registerButton);
                loginButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String str1 = userText.getText();
        char[] p = passwordText.getPassword();
        String str2 = new String(p);
        UserManager um=new UserManager();
        boolean b= um.log(str1,str2);
       
        if(b){
            JOptionPane.showMessageDialog(null,
                   "Login Details are correct");
            MainForm mf=new MainForm();
            mf.show();
        }
        else
        {
            JOptionPane.showMessageDialog(null,
                   "Incorrect email-Id or password..Try Again with correct detail");
        }
    }
}
