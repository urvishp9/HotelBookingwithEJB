/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import SESSIONBEANS.RoomSessionBeanRemote;

/**
 *
 * @author Urvish
 */
public class RoomManager {

    private RoomSessionBeanRemote lookupRoomStatelessSessionBeanRemote() {
        try {
            Context c = new InitialContext();
            return (RoomSessionBeanRemote) c.lookup("java:comp/env/RoomSessionBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
    public List getroom()
    {
        List ss=lookupRoomStatelessSessionBeanRemote().getRoomDetails();
        return ss;
    }
    
    public List getres()
    {
        List ss=lookupRoomStatelessSessionBeanRemote().getReservationDetails();
        return ss;
    }
    
    public void bkroom(Object o){
        lookupRoomStatelessSessionBeanRemote().bookRoom(o);
    }
    
}
