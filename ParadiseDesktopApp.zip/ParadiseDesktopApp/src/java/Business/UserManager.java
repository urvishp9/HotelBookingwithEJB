/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import SESSIONBEANS.LoginSessionBeanRemote;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import SESSIONBEANS.RegisterSessionBeanRemote;
import SESSIONBEANS.RoomSessionBeanRemote;

/**
 *
 * @author Urvish
 */
public class UserManager {
    private LoginSessionBeanRemote lookupLoginStatefulSessionBeanRemote() {
        try {
            Context c = new InitialContext();
            return (LoginSessionBeanRemote) c.lookup("java:comp/env/LoginSessionBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
  //  String uname;
   // String pass;
    
    public boolean log(String uname,String pass){
    boolean o=  lookupLoginStatefulSessionBeanRemote().getAuthenticatedUser(uname,pass);//ser(uname,pass); 
    return o;
    }

    private RoomSessionBeanRemote lookupRoomStatelessSessionBeanRemote() {
        try {
            Context c = new InitialContext();
            return (RoomSessionBeanRemote) c.lookup("java:comp/env/RoomSessionBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
    public List Allrooms(){
      List alroom=new ArrayList();
     alroom= lookupRoomStatelessSessionBeanRemote().getRoomDetails();
      return alroom;
    }
    
   // public  List AvailRooms(){
    //}

    private RegisterSessionBeanRemote lookupRegisterSessionBeanRemote() {
        try {
            Context c = new InitialContext();
            return (RegisterSessionBeanRemote) c.lookup("java:comp/env/RegisterSessionBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
    public void s(){
    }
   
    
}
