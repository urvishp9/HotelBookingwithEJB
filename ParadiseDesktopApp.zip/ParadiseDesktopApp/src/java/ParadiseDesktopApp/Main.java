/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParadiseDesktopApp;

import Forms.Login;
import Forms.LoginForm;
import java.awt.Frame;
import java.util.List;
import javax.ejb.EJB;
import SESSIONBEANS.LoginSessionBeanRemote;
import SESSIONBEANS.RoomSessionBeanRemote;


/**
 *
 * @author Urvish
 */
public class Main {
    
    @EJB
    private static RoomSessionBeanRemote roomSessionBean;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame frame = new Frame();
        frame.setUndecorated(true);
        // TODO code application logic here
       // RemoteConnect rc=new RemoteConnect();
   // rc.checklogin("admin", "shah");
   //  boolean a=   loginStatefulSessionBean.getAuthenticatedUser("admin", "shah");
  //  Login l=new Login();
    LoginForm lf=new LoginForm();
     // boolean a=  loginStatefulSessionBean.getAuthenticatedUser("admin", "admin");
       //          System.err.println(a);

    //List ss= roomStatelessSessionBean.getRoomDetails();
    
      //  for (Object s: ss) {
        //    System.err.println(s);
            
        //}
}
}
